import matplotlib.pyplot as plt
from Pr2.DotsAndLines.Point import Point


class GraphicManager:
    @staticmethod
    def draw(points: list[Point], lines: list[tuple[Point, Point, Point, Point]], label: str = None):
        plt.title(label)
        plt.scatter(list(map(lambda point: point.x, points)), list(map(lambda point: point.y, points)))

        for line in lines:
            plt.plot([line[0].x, line[1].x, line[2].x, line[3].x],
                     [line[0].y, line[1].y, line[2].y, line[3].y])

        plt.show()
